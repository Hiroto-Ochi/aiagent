# n8n Azure デプロイメント変更履歴

## 概要
Azure Container Apps上でのn8nアプリケーションデプロイメント時に発生した権限とリソース設定の問題を解決するため、複数の一時的な変更を実施しました。

## 変更日時
- 実施日: 2025年7月18日
- 作業者: uu292339
- 環境: Azure サブスクリプション `79e9d7d7-a82b-4277-a786-8ad3636c0a1c`

## 実施した変更

### 1. Microsoft.Appプロバイダーの登録
```bash
az provider register --namespace Microsoft.App
```

**理由**: Container Apps使用に必要なプロバイダーが未登録だった
**影響**: Container Appsリソースの作成が可能になった

### 2. Key Vaultのロール割り当て機能を一時無効化

**変更ファイル**: `key-vault.tf`

```hcl
# 一時的にコメントアウト - 権限取得後に有効化
# role_assignments = {
#   deployment_user_kv_admin = {
#     role_definition_id_or_name = "Key Vault Administrator"
#     principal_id               = data.azurerm_client_config.current.object_id
#   }
#   container_app_kv_user = {
#     role_definition_id_or_name = "Key Vault Secrets User"
#     principal_id               = azurerm_user_assigned_identity.this.principal_id
#   }
# }
```

**理由**: `Microsoft.Authorization/roleAssignments/write`権限不足
**影響**: 
- ✅ Key Vaultリソース自体は作成可能
- ❌ 自動的なロール割り当てが無効
- ❌ シークレットの自動管理が無効

### 3. Key Vaultシークレット機能を一時無効化

**変更ファイル**: `key-vault.tf`

```hcl
# 権限取得後に有効化
# secrets = {
#   openai-key = {
#     name = "openai-key"
#   }
#   psqladmin-password = {
#     name = "psqladmin-password"
#   }
# }

# secrets_value = {
#   openai-key         = module.openai.primary_access_key
#   psqladmin-password = random_password.myadminpassword.result
# }
```

**理由**: Key Vaultアクセス権限不足
**影響**: 
- ❌ OpenAI APIキーの自動保存が無効
- ❌ DBパスワードの自動保存が無効
- ⚠️ セキュリティレベルの一時的低下

### 4. OpenAIサービスのリージョン変更

**変更ファイル**: `openai.tf`

```hcl
location = "eastus"  # japaneast から変更
```

**理由**: Japan Eastリージョンで`Standard` SKUがサポートされていない
**影響**: 
- ✅ OpenAIリソースの作成が可能
- ⚠️ 地理的に離れた場所へのデプロイ（レイテンシ増加の可能性）

### 5. OpenAIデプロイメントを一時無効化

**変更ファイル**: `openai.tf`

```hcl
# 一時的にコメントアウト - 権限解決後に有効化
# cognitive_deployments = {
#   "gpt-4o-mini" = {
#     name = "gpt-4o-mini"
#     model = {
#       format  = "OpenAI"
#       name    = "gpt-4o-mini"
#       version = "2024-07-18"
#     }
#     scale = {
#       type     = "Standard"
#       capacity = 8
#     }
#   }
# }
```

**理由**: 組織ポリシーによる`GlobalStandard` SKU制限
**影響**: 
- ❌ GPT-4o-miniモデルが利用不可
- ❌ n8nでのAI機能が利用不可

### 6. 関連Outputsの一時無効化

**変更ファイル**: `outputs.tf`

```hcl
# 一時的にコメントアウト - Key Vault権限取得後に有効化
# output "openai_key_secret_url" { ... }
# output "openai_deployment_name" { ... }
# output "openai_api_version" { ... }
```

**理由**: 無効化されたリソースへの参照エラー防止
**影響**: 
- ❌ デプロイ後の設定情報出力が制限

### 7. n8nアプリでのDBパスワード直接設定

**変更ファイル**: `container-apps.tf`

```hcl
{
  name  = "DB_POSTGRESDB_PASSWORD"
  value = random_password.myadminpassword.result  # Key Vaultシークレット参照から変更
}
```

**理由**: Key Vaultシークレットが利用不可のため
**影響**: 
- ✅ n8nアプリケーションの正常起動
- ⚠️ パスワードがコンテナ環境変数に直接露出

## 現在の状態

### ✅ 正常稼働中のリソース
- Resource Group: `rg-w00c`
- Container App Environment: `cae-w00c`
- n8n Container App: `ca-w00c-n8n`
- PostgreSQL Flexible Server: `psql-w00c`
- Storage Account: `stw00c`
- Key Vault: `kv-w00c` (空の状態)
- User Assigned Identity: `uai-w00c`
- OpenAI Cognitive Account: `cog-w00c` (East USリージョン)

### ❌ 無効化中のリソース
- OpenAI GPT-4o-mini デプロイメント
- Key Vault シークレット管理
- Key Vault ロール割り当て

## 復旧手順

### 1. 権限取得
以下の権限を管理者から取得：
```
スコープ: /subscriptions/79e9d7d7-a82b-4277-a786-8ad3636c0a1c/resourceGroups/rg-w00c
ロール: User Access Administrator
ユーザー: yui.tabuchi@waku-2.com
```

### 2. Key Vault機能の復旧
1. `key-vault.tf`のコメントアウトを解除
2. `terraform plan`と`terraform apply`を実行

### 3. OpenAI機能の復旧
1. 組織ポリシーの確認・調整
2. `openai.tf`のコメントアウトを解除
3. SKU設定の調整（必要に応じて）
4. `terraform plan`と`terraform apply`を実行

### 4. Outputs情報の復旧
1. `outputs.tf`のコメントアウトを解除
2. `terraform plan`と`terraform apply`を実行

### 5. セキュリティ設定の改善
1. n8nアプリでKey Vaultシークレット参照に変更
2. 環境変数からパスワード直接設定を削除

## セキュリティ考慮事項

### 現在のリスク
- DBパスワードがコンテナ環境変数に露出
- OpenAI APIキーが外部Key Vaultに保存されていない
- 自動的なシークレットローテーションが無効

### 推奨対策
1. **緊急**: 権限取得後のKey Vault機能復旧
2. **重要**: セキュリティ監査ログの確認
3. **推奨**: パスワードローテーションの実施

## コスト影響

### 追加コスト
- OpenAI Cognitive Account (East USリージョン): 使用量に応じた課金
- Container Apps: 実行時間とリソース使用量に応じた課金

### コスト削減の機会
- 不要なOpenAI Cognitive Accountの削除（復旧後）
- Container Appsのオートスケール設定最適化

## 今後の改善点

1. **事前権限確認**: デプロイ前の権限要件チェックリスト作成
2. **段階的デプロイ**: 依存関係を考慮した段階的なリソース作成
3. **ポリシー調査**: 組織ポリシーの事前確認プロセス
4. **バックアップ戦略**: Key Vault無効時の代替セキュリティ設定
5. **監視設定**: リソース状態の継続的監視

## 関連ファイル
- `key-vault.tf` - Key Vault設定
- `openai.tf` - OpenAI設定  
- `container-apps.tf` - Container Apps設定
- `outputs.tf` - 出力設定
- `variables.tf` - 変数定義

---
**注意**: このドキュメントは一時的な回避策を記録したものです。本番運用前には必ずセキュリティ要件を満たす完全な設定に戻してください。
