# n8n Azure Container Apps アーキテクチャ図

## システム構成図

```mermaid
graph LR

  subgraph "CI/CD & 管理"
    GitHub["GitHub リポジトリ <br>(Terraformコード)"]
    CLI["開発者/運用者 <br>(Terraform CLI)"]
    CLI -- "terraform apply" --> AzureResources
    GitHub --> CLI
  end

  subgraph "Azure リソース"
    direction TB
    AzureResources[" "]
    style AzureResources fill:none,stroke:none

    subgraph "監視"
      Monitor["Azure Monitor"]
      style Monitor fill:#B2E2F2,stroke:#0078D4
    end

    subgraph "ホスティング <br>(Azure Container Apps)"
      ACA_N8N["n8n Container App <br>(外部公開 HTTPS)"]
      ACA_MCP["MCP Server Container App <br>for Azure AI<br>(外部公開 HTTPS, オプション)"]
      style ACA_N8N fill:#0078D4,stroke:#005A9E,color:white
      style ACA_MCP fill:#0078D4,stroke:#005A9E,color:white
    end

    subgraph "データストレージ"
      PostgreSQL["Azure Database for PostgreSQL <br>(n8nデータベース)"]
      style PostgreSQL fill:#78B800,stroke:#4C7300,color:white
      StorageAcct["Azure Storage Account"]
      FileShare["Azure File Share <br>(n8n設定ファイル)"]
      style StorageAcct fill:#FF8C00,stroke:#CC7000,color:white
      style FileShare fill:#FFB900,stroke:#CC9400,color:black
    end

    subgraph "AI & <br>セキュリティコンポーネント"
      OpenAI["Azure OpenAI <br>(gpt-4o-mini)"]
      style OpenAI fill:#7F00FF,stroke:#5700AD,color:white
      KeyVault["Azure Key Vault <br>(シークレット管理)"]
      style KeyVault fill:#FFD700,stroke:#B8860B,color:black
      UAI["User Assigned Identity <br>(マネージドID)"]
      style UAI fill:#C0C0C0,stroke:#808080,color:black
    end

    %% 関係性
    ACA_N8N -- "データ永続化 <br>(SSL強制)" --> PostgreSQL
    ACA_N8N -- "設定ファイル永続化 <br>(Volume Mount)" --> FileShare
    FileShare -- "所属" --> StorageAcct
    ACA_N8N -- "シークレット取得 <br>(DBパスワード, OpenAIキー等)" --> KeyVault
    ACA_N8N -- "IDとして使用" --> UAI

    ACA_MCP -- "IDとして使用" --> UAI

    UAI -- "Key Vaultシークレット読み取り権限 <br>(RBAC)" --> KeyVault
    KeyVault -- "OpenAI APIキー格納" --> OpenAI
    KeyVault -- "PostgreSQL<br>管理者パスワード格納" --> PostgreSQL

    %% 監視 (各サービスからMonitorへ点線で示す)
    ACA_N8N -.-> Monitor
    ACA_MCP -.-> Monitor
    PostgreSQL -.-> Monitor
    StorageAcct -.-> Monitor
    OpenAI -.-> Monitor
    KeyVault -.-> Monitor
  end

  subgraph "外部アクセス"
    Internet["n8n WEBアプリケーション"]
    Internet -- "HTTPS <br>(n8n UI/API)" --> ACA_N8N
    Internet -- "HTTPS <br>(MCP SSE Endpoint, オプション)" --> ACA_MCP
  end
```

## セキュリティ対策の詳細

```mermaid
graph TD
    subgraph "セキュリティ対策の柱"
        direction LR
        A["<b style='color:#000000;'>セキュリティ対策</b><br>(Terraform構成全体)"] --- Cat1
        A --- Cat2
        A --- Cat3
        A --- Cat4
        A --- Cat5

        Cat1["<b style='color:#4682B4;'>IDとアクセス管理</b><br>(Azure AD, 各リソース)"]
        Cat1 --> C1_Item1["マネージドID (UAI)<br>(User Assigned ID)<br><br><b>役割:</b> Azureリソース間認証<br>コードから資格情報排除。"]
        Cat1 --> C1_Item2["RBAC<br>(ロールベースアクセス制御)<br><br><b>役割:</b> 最小権限の原則で<br>アクセス権を付与。"]

        Cat2["<b style='color:#3CB371;'>データ保護</b><br>(Key Vault, 通信, Storage)"]
        Cat2 --> C2_Item1["Azure Key Vault<br>(Key Vault)<br><br><b>役割:</b> 機密情報 (APIキー等)<br>を安全に保管・管理。"]
        Cat2 --> C2_Item2["通信の暗号化<br>(TLS/SSL)<br><br><b>役割:</b> データ送受信時の<br>盗聴・改ざんを防止。"]
        Cat2 --> C2_Item3["ストレージアクセスキー<br>(Storage Account)<br><br><b>役割:</b> FileShareマウント等に<br>限定して使用。"]

        Cat3["<b style='color:#FF8C00;'>ネットワークセキュリティ</b><br>(ACA, PG, KV)"]
        Cat3 --> C3_Item1["HTTPS強制<br>(Container Apps)<br><br><b>役割:</b> Webアクセスを<br>HTTPSに限定し通信暗号化"]
        Cat3 --> C3_Item2["ファイアウォールルール<br>(PostgreSQL)<br><br><b>役割:</b> DBへのアクセス元IPを<br>制限し不正アクセス防止。"]
        Cat3 --> C3_Item3["ネットワークACL<br>(Key Vault)<br><br><b>役割:</b> Key Vaultへのアクセス元<br>ネットワークを制限。"]

        Cat4["<b style='color:#DA70D6;'>アプリケーションセキュリティ</b><br>(n8nコンテナ設定)"]
        Cat4 --> C4_Item1["セキュアな環境変数<br>(ACA, Key Vault)<br><br><b>役割:</b> 機密情報をKV経由で<br>安全にアプリへ設定。"]
        Cat4 --> C4_Item2["WEBHOOK_URL (HTTPS)<br>(n8nアプリ)<br><br><b>役割:</b> Webhook通信をHTTPS化し<br>データ連携を保護。"]

        Cat5["<b style='color:#8A2BE2;'>構成と運用</b><br>(Terraform, Azure基盤)"]
        Cat5 --> C5_Item1["Azure Verified Modules<br>(Terraform)<br><br><b>役割:</b> MS推奨モジュールで<br>信頼性の高い構成。"]
        Cat5 --> C5_Item2["Infrastructure as Code<br>(Terraform)<br><br><b>役割:</b> コードでインフラ管理し<br>再現性・一貫性を向上。"]
        Cat5 --> C5_Item3["Azure Monitor<br>(Azure)<br><br><b>役割:</b> リソースの基本監視<br>(メトリック, ログ収集)。"]
    end

    classDef categoryNode fill:#E6E6FA,stroke:#333,stroke-width:2px,color:black,font-weight:bold
    class A,Cat1,Cat2,Cat3,Cat4,Cat5 categoryNode;
```