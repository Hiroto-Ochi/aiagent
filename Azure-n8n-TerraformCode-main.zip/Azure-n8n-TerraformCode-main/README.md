# n8n Azure Container Apps デプロイメント

このTerraform構成は、**Azure Container Apps** 上に **n8n** インスタンスを、**GPT-4o-mini** モデルを搭載した **Azure OpenAI Service** インスタンスと共にデプロイします。Azure Container Apps を活用することで、n8n [公式サイト](https://docs.n8n.io/hosting/installation/server-setups/azure/) で説明されているAzure Kubernetes Service (AKS) へのデプロイに対して、コスト効率の良い代替手段を提供します。Azure Container Apps により、スケーラビリティを維持しながらデプロイメントプロセスを簡素化できます。
 
### 主要機能:
- **n8n アプリケーション**: Azure Container Apps を使用して、高可用性でスケーラブルな環境に強力なワークフロー自動化ツールであるn8nをデプロイします。
- **Azure MCP サーバーコンテナ**: MCP/Azure と統合された追加コンテナアプリをオプションでデプロイし、n8n内のAIエージェントにAzure固有のコンテキストを提供します。
- **Azure OpenAI 統合**: GPT-4o-miniモデルを搭載したAzure OpenAI Service インスタンスを提供し、ワークフローに高度なAI機能を実現します。
- **コスト最適化**: Azure Container Apps を活用してAKSと比較して1/5程度までコストを最小化します。
- **セキュアな構成**: Azure Key Vault と統合して、APIキーやシークレットなどの機密情報を安全に管理します。
- **カスタマイズ可能なデプロイメント**: リージョン、タグ、テレメトリの柔軟な設定オプションをサポートし、特定のニーズに合わせてデプロイメントを調整できます。
- **Azure Verified Modules**: Azure Verified Modules (AVM) を活用して、十分に定義され、テストされ、Microsoft がサポートするモジュールの使用を保証し、信頼性と保守性を向上させます。

このリポジトリは、AKS ベースのソリューションが単一用途には高額であるため、Azure クラウドでより手頃で利用しやすい方法でn8nをホストする方法を提供するために作成されました。この構成は、n8n と Azure OpenAI の力を Azure Container Apps のコスト効率性とシンプルさと組み合わせた実用的な代替手段を提供します。

## アーキテクチャの詳細解説

### 📊 システム構成図

このシステム全体の構成と各コンポーネントの関係性については、詳細なアーキテクチャ図をご用意しています：

📎 **[アーキテクチャ図を見る](./architecture-diagram.md)**

アーキテクチャ図では以下の内容を視覚的に確認できます：
- **システム構成図**: 全コンポーネントとデータフローの全体像
- **セキュリティ対策**: 5つのセキュリティの柱と具体的な実装方法
- **構成の特徴**: コスト効率性、セキュリティ、運用性の詳細

### 本プロジェクトの.tfファイル構成と役割

#### 📋 設定・管理系ファイル

| ファイル名 | 役割 | 内容 |
|-----------|------|------|
| **provider.tf** | プロバイダー設定 | Azureとの接続設定、認証方法、使用するAPIバージョンを定義 |
| **variables.tf** | 入力変数定義 | デプロイ時に指定できるパラメータ（リージョン、サブスクリプション ID など）を定義 |
| **outputs.tf** | 出力値定義 | デプロイ完了後に表示される重要な情報（n8nのURLやOpenAIの設定値など）を定義 |

#### 🏗️ リソース定義系ファイル

| ファイル名 | 役割 | 作成されるAzureリソース |
|-----------|------|----------------------|
| **foundation.tf** | 基盤リソース | リソースグループ、マネージドID、命名規則 |
| **container-apps.tf** | Container Apps | Container Apps環境、n8nアプリ、MCPサーバー、永続ストレージ設定 |
| **key-vault.tf** | Key Vault | 機密情報管理（OpenAI APIキー、データベースパスワード） |
| **openai.tf** | AI サービス | Azure OpenAI サービス、GPT-4o-miniモデル |
| **postgresql.tf** | データベース | PostgreSQL Flexible Server、データベース、管理者パスワード |
| **storage.tf** | ストレージ | Storage Account、File Share（n8n設定用） |

#### 📊 実行・状態管理ファイル

| ファイル名 | 役割 | 説明 |
|-----------|------|------|
| **.terraform.lock.hcl** | 依存関係ロック | 使用するプロバイダーのバージョンを固定（自動生成） |
| **tfplan** | 実行計画 | `terraform plan` で生成される実行予定の詳細（バイナリファイル） |
| **terraform.tfvars** | 実際の設定値 | 本番で使用する具体的な値（サブスクリプション ID など）<br/>⚠️ 機密情報のため .gitignore で除外 |

### ファイル間の関係性

```
variables.tf     →  各リソースファイル  →  outputs.tf
（入力パラメータ）    （実際のリソース）     （結果の出力）
     ↓                   ↓                 ↓
terraform.tfvars  →  provider.tf     →  tfplan
（具体的な値）      （Azure接続設定）    （実行計画）
```

### なぜファイルを分割するのか？

1. **可読性**: 機能ごとに分かれているため、目的のリソースを素早く見つけられる
2. **保守性**: 特定の機能（例: OpenAI設定）だけを変更したい場合、該当ファイルのみ編集すれば良い
3. **再利用性**: 一部のファイル（例: openai.tf）を他のプロジェクトで再利用可能
4. **チーム開発**: 異なる担当者が異なるファイルを同時に編集可能
5. **リスク管理**: 重要な機密情報（terraform.tfvars）を分離して管理

## 前提条件

デプロイを開始する前に、以下の前提条件を満たしていることを確認してください：

### 必要なツール
- **Terraform** >= 1.11
- **Azure CLI** >= 2.50.0
- **Git** (このリポジトリをクローンするため)

### Azureアカウント要件
- 有効なAzureサブスクリプション
- サブスクリプションに対する「**共同作成者**」以上の権限
- Azure OpenAI Service へのアクセス許可 (要申請の場合があります)

### 事前準備
1. Azure CLIへのログイン:
   ```bash
   az login
   az account set --subscription "your-subscription-id"
   ```

2. Terraform の初期化確認:
   ```bash
   terraform --version
   ```

## デプロイ手順

### 1. リポジトリのクローン
```bash
git clone <repository-url>
cd LinkX_n8n
```

### 2. 設定ファイルの作成
`terraform.tfvars` ファイルを作成し、以下のテンプレートに基づいて値を設定してください：

```hcl
# terraform.tfvars.example
# このファイルを terraform.tfvars としてコピーし、値を設定してください。

subscription_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"  # Azureサブスクリプション ID
location        = "japaneast"                            # デプロイ先リージョン
deploy_mcp      = true                                   # MCPコンテナアプリをデプロイするか

# リソースタグ（オプション）
tags = {
  Environment = "Development"      # 環境名（開発、本番など）
  ManagedBy   = "YourCompanyName" # 管理者・会社名
  Project     = "n8n-automation"  # プロジェクト名
}

# 命名規則（オプション）
resource_prefix = ""    # リソース名の接頭辞（例: "prod-", "dev-"）
resource_suffix = ""    # リソース名の接尾辞（例: "-001", "-japan"）
```

### 3. Azure CLI認証の確認
デプロイ前に、Azure CLIで正しいサブスクリプションにログインしていることを確認してください：

```bash
# 現在のログイン状態を確認
az account show

# 必要に応じて再ログイン
az login

# 正しいサブスクリプションを設定
az account set --subscription "your-subscription-id"

# サブスクリプションIDを確認（terraform.tfvarsで使用）
az account show --query id --output tsv
```

### 4. Terraformの初期化と実行

#### 4.1 初期化
```bash
# Terraformの初期化（プロバイダーとモジュールをダウンロード）
terraform init
```

#### 4.2 実行計画の確認
```bash
# 実行計画を表示（どのリソースが作成されるかを確認）
terraform plan

# より詳細な計画を表示したい場合
terraform plan -detailed-exitcode
```

#### 4.3 デプロイの実行
```bash
# 対話形式でのデプロイ
terraform apply

# 自動承認でのデプロイ（CI/CD環境など）
terraform apply -auto-approve

# 特定のリソースのみをデプロイ
terraform apply -target=module.container_app_n8n
```

### 5. デプロイ状況の確認

#### 5.1 リソース状態の確認
```bash
# 現在のTerraform状態を表示
terraform show

# リソース一覧を表示
terraform state list

# 特定のリソースの詳細を表示
terraform state show module.container_app_n8n
```

#### 5.2 出力値の確認
```bash
# 全ての出力値を表示
terraform output

# 特定の出力値のみを表示
terraform output n8n_fqdn_url

# JSON形式で出力値を表示
terraform output -json
```

### 6. Azure Portal での確認
デプロイ完了後、Azure Portal で以下を確認してください：

1. **リソースグループ**: 全てのリソースが正常に作成されているか
2. **Container Apps**: n8nアプリケーションが稼働しているか
3. **PostgreSQL**: データベースが接続可能な状態か
4. **Key Vault**: シークレットが正常に格納されているか
5. **OpenAI**: サービスがアクティブになっているか


## 技術仕様書

### 必要要件

| 名前 | バージョン |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 1.11 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4, < 5.0.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | ~> 3.7 |

### プロバイダー

| 名前 | バージョン |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 4.26.0 |
| <a name="provider_random"></a> [random](#provider\_random) | 3.7.1 |

### モジュール

| 名前 | ソース | バージョン |
|------|--------|---------|
| <a name="module_container_app_mcp"></a> [container\_app\_mcp](#module\_container\_app\_mcp) | Azure/avm-res-app-containerapp/azurerm | 0.4.0 |
| <a name="module_container_app_n8n"></a> [container\_app\_n8n](#module\_container\_app\_n8n) | Azure/avm-res-app-containerapp/azurerm | 0.4.0 |
| <a name="module_key_vault"></a> [key\_vault](#module\_key\_vault) | Azure/avm-res-keyvault-vault/azurerm | 0.10.0 |
| <a name="module_naming"></a> [naming](#module\_naming) | Azure/naming/azurerm | 0.4.0 |
| <a name="module_openai"></a> [openai](#module\_openai) | Azure/avm-res-cognitiveservices-account/azurerm | 0.7.0 |
| <a name="module_postgresql"></a> [postgresql](#module\_postgresql) | Azure/avm-res-dbforpostgresql-flexibleserver/azurerm | 0.1.4 |
| <a name="module_storage"></a> [storage](#module\_storage) | Azure/avm-res-storage-storageaccount/azurerm | 0.5.0 |

### リソース

| 名前 | 種類 |
|------|------|
| [azurerm_container_app_environment.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/container_app_environment) | リソース |
| [azurerm_container_app_environment_storage.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/container_app_environment_storage) | リソース |
| [azurerm_resource_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | リソース |
| [azurerm_user_assigned_identity.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | リソース |
| [random_password.myadminpassword](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | リソース |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | データソース |