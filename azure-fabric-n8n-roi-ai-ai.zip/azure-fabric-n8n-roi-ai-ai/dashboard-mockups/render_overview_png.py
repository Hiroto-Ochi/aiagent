from PIL import Image, ImageDraw, ImageFont
from pathlib import Path


OUT = Path(__file__).with_name("ai-agent-ops-dashboard-overview.png")
W, H = 1600, 2100

COLORS = {
    "bg": "#f6f7f9",
    "panel": "#ffffff",
    "panel_head": "#fbfcfe",
    "ink": "#172033",
    "muted": "#647084",
    "line": "#d9dee8",
    "blue": "#2563eb",
    "teal": "#0f766e",
    "green": "#15803d",
    "amber": "#b45309",
    "red": "#b91c1c",
    "purple": "#7c3aed",
    "cyan": "#0891b2",
    "steel": "#475569",
    "soft_blue": "#dbeafe",
    "soft_green": "#dcfce7",
    "soft_amber": "#fef3c7",
    "soft_red": "#fee2e2",
    "soft_cyan": "#cffafe",
    "track": "#eef2f7",
}


FONT_REGULAR = Path("C:/Windows/Fonts/meiryo.ttc")
FONT_BOLD = Path("C:/Windows/Fonts/meiryob.ttc")


def font(size, bold=False):
    path = FONT_BOLD if bold and FONT_BOLD.exists() else FONT_REGULAR
    if path.exists():
        return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default()


F = {
    "title": font(34, True),
    "subtitle": font(17),
    "h2": font(22, True),
    "h3": font(15, True),
    "label": font(13, True),
    "small": font(12),
    "tiny": font(11),
    "kpi": font(25, True),
    "pill": font(11, True),
}


def rr(draw, xy, fill, outline=None, width=1, radius=8):
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=width)


def txt(draw, xy, text, fill="ink", f="small", anchor=None):
    draw.text(xy, text, fill=COLORS.get(fill, fill), font=F[f], anchor=anchor)


def panel(draw, x, y, w, h, title, badge):
    rr(draw, (x, y, x + w, y + h), COLORS["panel"], COLORS["line"], 1, 8)
    rr(draw, (x + 1, y + 1, x + w - 1, y + 59), COLORS["panel_head"], radius=8)
    draw.line((x, y + 60, x + w, y + 60), fill=COLORS["line"], width=1)
    txt(draw, (x + 22, y + 20), title, f="h2")
    bx = x + w - 150
    rr(draw, (bx, y + 18, bx + 122, y + 44), COLORS["soft_cyan"], radius=13)
    txt(draw, (bx + 61, y + 23), badge, fill="#155e75", f="pill", anchor="ma")


def kpi_box(draw, x, y, label, value, color):
    rr(draw, (x, y, x + 162, y + 72), COLORS["panel"], COLORS["line"], 1, 8)
    txt(draw, (x + 14, y + 12), label, fill="muted", f="label")
    txt(draw, (x + 14, y + 39), value, fill=color, f="kpi")


def bar(draw, x, y, label, value, pct, color, maxw=360):
    txt(draw, (x, y), label, f="small")
    rr(draw, (x + 160, y - 12, x + 160 + maxw, y + 4), COLORS["track"], radius=4)
    rr(draw, (x + 160, y - 12, x + 160 + int(maxw * pct), y + 4), COLORS[color], radius=4)
    txt(draw, (x + 160 + maxw + 16, y - 2), value, f="small")


def roi_panel(draw, x, y):
    panel(draw, x, y, 740, 430, "1. AI投資対効果", "Executive KPI")
    for i, item in enumerate([
        ("月間削減時間", "1,670h", "teal"),
        ("削減換算額", "¥6.68M", "blue"),
        ("AI/API費用", "¥460K", "amber"),
        ("純効果", "¥4.86M", "green"),
    ]):
        kpi_box(draw, x + 22 + i * 178, y + 82, *item)
    txt(draw, (x + 22, y + 176), "AIエージェント別 純効果", f="h3")
    bar(draw, x + 22, y + 226, "社内ナレッジ調査AI", "¥2.35M", 1.00, "blue")
    bar(draw, x + 22, y + 260, "経費精算チェックAI", "¥1.27M", 0.54, "teal")
    bar(draw, x + 22, y + 294, "データ品質チェックAI", "¥0.99M", 0.42, "green")
    bar(draw, x + 22, y + 328, "規程問い合わせAI", "¥0.26M", 0.11, "amber")
    sx, sy = x + 510, y + 206
    txt(draw, (sx, sy - 22), "実行回数 × ROI", f="h3")
    draw.line((sx, sy + 138, sx + 174, sy + 138), fill="#cbd5e1", width=1)
    draw.line((sx, sy, sx, sy + 138), fill="#cbd5e1", width=1)
    draw.line((sx, sy + 84, sx + 174, sy + 84), fill="#f97316", width=2)
    for cx, cy, r, c in [(46, 34, 18, "teal"), (146, 52, 25, "blue"), (28, 28, 17, "green"), (44, 112, 13, "amber")]:
        draw.ellipse((sx + cx - r, sy + cy - r, sx + cx + r, sy + cy + r), fill=COLORS[c])
    txt(draw, (sx + 92, sy + 154), "実行回数", fill="muted", f="tiny")


def ops_panel(draw, x, y):
    panel(draw, x, y, 740, 430, "2. 稼働率・安定性", "Real-Time")
    for i, item in enumerate([
        ("本日実行", "8,420", "blue"),
        ("成功率", "97.8%", "green"),
        ("平均処理", "34s", "teal"),
        ("重大エラー", "12", "red"),
    ]):
        kpi_box(draw, x + 22 + i * 178, y + 82, *item)
    lx, ly = x + 24, y + 192
    txt(draw, (lx, ly), "時間帯別 実行件数/失敗率", f="h3")
    draw.line((lx, ly + 170, lx + 300, ly + 170), fill="#cbd5e1", width=1)
    draw.line((lx, ly + 28, lx, ly + 170), fill="#cbd5e1", width=1)
    draw.line([(lx + a, ly + b) for a, b in [(8,160),(58,118),(108,48),(158,66),(208,84),(258,116),(300,142)]], fill=COLORS["blue"], width=4, joint="curve")
    draw.line([(lx + a, ly + b) for a, b in [(8,174),(58,168),(108,146),(158,152),(208,110),(258,158),(300,166)]], fill=COLORS["red"], width=3, joint="curve")
    fx, fy = x + 385, y + 192
    txt(draw, (fx, fy), "処理ファネル", f="h3")
    for i, (name, count, pct, color) in enumerate([
        ("受付", "8,420", 1.00, "blue"),
        ("n8n処理", "8,010", 0.94, "teal"),
        ("AI処理", "7,780", 0.89, "purple"),
        ("DB更新", "7,650", 0.86, "green"),
    ]):
        yy = fy + 25 + i * 43
        rr(draw, (fx, yy, fx + int(280 * pct), yy + 34), COLORS[color], radius=5)
        txt(draw, (fx + 12, yy + 8), f"{name} {count}", fill="#ffffff", f="small")


def business_panel(draw, x, y):
    panel(draw, x, y, 740, 430, "3. 業務可視化", "業務マップ")
    txt(draw, (x + 24, y + 82), "削減時間の大きい業務領域", f="h3")
    tx, ty = x + 24, y + 118
    tiles = [
        (0, 0, 270, 245, "blue", "社内FAQ/ナレッジ", "760h", "AI対応率 72%"),
        (286, 0, 190, 118, "teal", "経費精算", "420h", ""),
        (492, 0, 178, 118, "green", "データ確認", "310h", ""),
        (286, 134, 190, 111, "amber", "規程確認", "180h", ""),
        (492, 134, 178, 111, "cyan", "営業資料確認", "140h", ""),
    ]
    for dx, dy, w, h, c, label, value, sub in tiles:
        rr(draw, (tx + dx, ty + dy, tx + dx + w, ty + dy + h), COLORS[c], radius=8)
        txt(draw, (tx + dx + 16, ty + dy + 18), label, fill="#ffffff", f="label")
        txt(draw, (tx + dx + 16, ty + dy + 50), value, fill="#ffffff", f="kpi")
        if sub:
            txt(draw, (tx + dx + 16, ty + dy + h - 28), sub, fill="#dbeafe", f="small")
    txt(draw, (x + 24, y + 378), "部門 × 業務カテゴリでAI活用度を可視化し、次の投資領域を判断", fill="muted", f="small")


def quality_panel(draw, x, y):
    panel(draw, x, y, 740, 430, "4. 品質・信頼性", "採用品質")
    for i, item in enumerate([
        ("平均採用率", "80.5%", "green"),
        ("差し戻し率", "6.8%", "red"),
        ("レビュー対象", "1,220", "amber"),
        ("品質スコア", "83", "blue"),
    ]):
        kpi_box(draw, x + 22 + i * 178, y + 82, *item)
    txt(draw, (x + 26, y + 192), "採用/修正/差し戻し 構成", f="h3")
    rows = [
        ("経費精算AI", 0.88, 0.07, 0.05),
        ("ナレッジAI", 0.76, 0.17, 0.07),
        ("データ品質AI", 0.90, 0.06, 0.04),
        ("規程AI", 0.68, 0.21, 0.11),
    ]
    for i, (name, ok, fix, back) in enumerate(rows):
        yy = y + 232 + i * 42
        txt(draw, (x + 26, yy), name, f="small")
        bx = x + 170
        rr(draw, (bx, yy - 14, bx + 410, yy + 4), COLORS["track"], radius=4)
        w1, w2, w3 = int(410 * ok), int(410 * fix), int(410 * back)
        draw.rectangle((bx, yy - 14, bx + w1, yy + 4), fill=COLORS["green"])
        draw.rectangle((bx + w1, yy - 14, bx + w1 + w2, yy + 4), fill=COLORS["amber"])
        draw.rectangle((bx + w1 + w2, yy - 14, bx + w1 + w2 + w3, yy + 4), fill=COLORS["red"])
    txt(draw, (x + 170, y + 392), "緑=採用 / 黄=修正あり / 赤=差し戻し", fill="muted", f="tiny")


def improvement_panel(draw, x, y):
    panel(draw, x, y, 740, 430, "5. 業務改善候補", "改善バックログ")
    txt(draw, (x + 24, y + 88), "改善優先度ランキング", f="h3")
    rows = [
        ("1", "社内ナレッジ調査AI: 古い文書参照", "損失 160h/月", "高", "red"),
        ("2", "データ品質チェックAI: DBタイムアウト", "損失 50h/月", "高", "red"),
        ("3", "経費精算AI: 例外規程に弱い", "損失 40h/月", "中", "amber"),
    ]
    for i, (no, title, loss, p, c) in enumerate(rows):
        yy = y + 124 + i * 66
        rr(draw, (x + 24, yy, x + 714, yy + 50), COLORS["panel"], COLORS["line"], 1, 8)
        draw.ellipse((x + 34, yy + 10, x + 64, yy + 40), fill="#111827")
        txt(draw, (x + 49, yy + 15), no, fill="#ffffff", f="pill", anchor="ma")
        txt(draw, (x + 80, yy + 10), title, f="label")
        txt(draw, (x + 80, yy + 30), loss, fill=c, f="small")
        rr(draw, (x + 624, yy + 14, x + 686, yy + 36), COLORS["soft_red" if c == "red" else "soft_amber"], radius=11)
        txt(draw, (x + 655, yy + 17), p, fill=c, f="pill", anchor="ma")
    mx, my = x + 420, y + 315
    rr(draw, (mx, my - 64, mx + 120, my - 6), COLORS["soft_green"], radius=0)
    rr(draw, (mx + 120, my - 64, mx + 240, my - 6), COLORS["soft_amber"], radius=0)
    rr(draw, (mx, my - 6, mx + 120, my + 52), COLORS["soft_cyan"], radius=0)
    rr(draw, (mx + 120, my - 6, mx + 240, my + 52), COLORS["soft_red"], radius=0)
    txt(draw, (mx + 60, my - 42), "即実行", fill="green", f="tiny", anchor="ma")
    txt(draw, (mx + 180, my - 42), "計画化", fill="amber", f="tiny", anchor="ma")
    txt(draw, (mx + 60, my + 16), "様子見", fill="#075985", f="tiny", anchor="ma")
    txt(draw, (mx + 180, my + 16), "要判断", fill="red", f="tiny", anchor="ma")


def consolidation_panel(draw, x, y):
    panel(draw, x, y, 740, 430, "6. AIエージェント統合候補", "乱立防止")
    txt(draw, (x + 24, y + 88), "類似エージェント ネットワーク", f="h3")
    ox, oy = x + 30, y + 120
    draw.line((ox + 110, oy + 72, ox + 270, oy + 64), fill="#9bbcff", width=7)
    draw.line((ox + 110, oy + 72, ox + 220, oy + 150), fill="#b7cbff", width=5)
    draw.line((ox + 270, oy + 64, ox + 220, oy + 150), fill="#b7cbff", width=5)
    draw.line((ox + 400, oy + 78, ox + 500, oy + 148), fill="#8ed4a2", width=6)
    nodes = [
        (110, 72, 46, "blue", "社内ナレッジ", "RAG"),
        (270, 64, 42, "purple", "規程問合せ", "RAG"),
        (220, 150, 38, "cyan", "社内FAQ", ""),
        (400, 78, 41, "green", "データ品質", ""),
        (500, 148, 38, "teal", "売上検証", ""),
        (560, 58, 30, "amber", "経費", ""),
    ]
    for cx, cy, r, c, label, sub in nodes:
        draw.ellipse((ox + cx - r, oy + cy - r, ox + cx + r, oy + cy + r), fill=COLORS[c])
        txt(draw, (ox + cx, oy + cy - 8), label, fill="#ffffff", f="small", anchor="ma")
        if sub:
            txt(draw, (ox + cx, oy + cy + 12), sub, fill="#e5f0ff", f="tiny", anchor="ma")
    txt(draw, (x + 24, y + 328), "統合候補スコア", f="label")
    for i, (label, color, soft) in enumerate([
        ("FAQ × 情シス: 84", "red", "soft_red"),
        ("ナレッジ × 規程: 80", "red", "soft_red"),
        ("品質 × 売上検証: 78", "amber", "soft_amber"),
    ]):
        bx = x + 24 + i * 204
        rr(draw, (bx, y + 346, bx + 190, y + 372), COLORS[soft], radius=5)
        txt(draw, (bx + 14, y + 352), label, fill=color, f="tiny")


def governance_panel(draw, x, y):
    panel(draw, x, y, 1520, 500, "7. ガバナンス・リスク", "監査・統制")
    cards = [
        (0, 460, "red", "高リスク実行", "328", "個人情報またはConfidentialデータ"),
        (500, 390, "amber", "レビュー未完了", "47", "当日中に確認"),
        (930, 500, "green", "監査証跡率", "99.2%", "実行IDと出力先を紐付け"),
    ]
    for dx, w, c, label, value, sub in cards:
        rr(draw, (x + 24 + dx, y + 84, x + 24 + dx + w, y + 172), COLORS[c], radius=8)
        txt(draw, (x + 42 + dx, y + 107), label, fill="#ffffff", f="label")
        txt(draw, (x + 42 + dx, y + 139), value, fill="#ffffff", f="kpi")
        txt(draw, (x + 42 + dx + 120, y + 143), sub, fill="#ffffff", f="small")
    txt(draw, (x + 24, y + 214), "リスクレベル別 実行件数", f="h3")
    for i, (label, value, pct, c) in enumerate([
        ("低: Internal FAQ", "5,840", 1.0, "green"),
        ("中: 売上/業務データ", "2,430", 0.42, "amber"),
        ("高: 個人情報/経費", "1,020", 0.18, "red"),
    ]):
        yy = y + 258 + i * 44
        txt(draw, (x + 24, yy), label, f="small")
        rr(draw, (x + 184, yy - 14, x + 644, yy + 4), COLORS["track"], radius=4)
        rr(draw, (x + 184, yy - 14, x + 184 + int(460 * pct), yy + 4), COLORS[c], radius=4)
        txt(draw, (x + 662, yy - 2), value, f="small")
    tx, ty = x + 820, y + 198
    txt(draw, (tx, ty), "監査サンプル", f="h3")
    rr(draw, (tx, ty + 20, tx + 650, ty + 54), "#f8fafc", radius=0)
    headers = [("実行ID", 14), ("AI", 110), ("データ分類", 230), ("PII", 350), ("レビュー", 430), ("リスク", 540)]
    for h, dx in headers:
        txt(draw, (tx + dx, ty + 32), h, fill="muted", f="tiny")
    rows = [
        ("EXE-1001", "経費精算", "Confidential", "あり", "あり", "高", "red", "soft_red"),
        ("EXE-1002", "ナレッジ", "Internal", "なし", "なし", "低", "green", "soft_green"),
        ("EXE-1003", "データ品質", "Confidential", "なし", "あり", "中", "amber", "soft_amber"),
    ]
    for i, row in enumerate(rows):
        yy = ty + 82 + i * 46
        vals = row[:5]
        for value, dx in zip(vals, [14, 110, 230, 350, 430]):
            txt(draw, (tx + dx, yy), value, f="small")
        rr(draw, (tx + 540, yy - 18, tx + 594, yy + 6), COLORS[row[7]], radius=12)
        txt(draw, (tx + 567, yy - 13), row[5], fill=row[6], f="pill", anchor="ma")
        draw.line((tx, yy + 18, tx + 650, yy + 18), fill=COLORS["line"], width=1)


def main():
    image = Image.new("RGB", (W, H), COLORS["bg"])
    draw = ImageDraw.Draw(image)
    draw.rectangle((0, 0, W, 92), fill="#101827")
    txt(draw, (42, 22), "AI Agent Operations Dashboard Mockups", fill="#ffffff", f="title")
    txt(draw, (42, 62), "n8nで増えるAIエージェントを、Fabricで価値・品質・稼働・改善・統合・リスクから経営管理する画面イメージ", fill="#cbd5e1", f="subtitle")
    draw.rectangle((0, 90, W, 95), fill="#2dd4bf")

    roi_panel(draw, 40, 125)
    ops_panel(draw, 820, 125)
    business_panel(draw, 40, 590)
    quality_panel(draw, 820, 590)
    improvement_panel(draw, 40, 1055)
    consolidation_panel(draw, 820, 1055)
    governance_panel(draw, 40, 1520)

    image.save(OUT, "PNG")
    print(OUT)


if __name__ == "__main__":
    main()
