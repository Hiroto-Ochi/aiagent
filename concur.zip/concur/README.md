# Expense Agent

Expense Agent is a sample application that uses Microsoft Azure services (Azure OpenAI, Cosmos DB, Blob Storage) to help you manage and analyze expense data with AI.

## Features

- Chat with an AI about your expenses
- Store and retrieve chat messages using Azure Cosmos DB
- Upload and manage files with Azure Blob Storage

## Getting Started

Follow these steps to set up and run the project, even if you are new to Azure or Python.

### 1. Prerequisites

- [Python 3.11+](https://www.python.org/downloads/) installed on your computer
- [uv](https://github.com/astral-sh/uv) package manager (for fast dependency management)
- An [Azure account](https://azure.microsoft.com/free/) with access to:
  - Azure OpenAI
  - Azure Cosmos DB
  - Azure Blob Storage

### 2. Clone the Repository

Open a terminal and run:

```sh
git clone https://github.com/your-username/expense_agent.git
cd expense_agent
```

### 3. Set Up Environment Variables

1. Find the `.env_temp` file in the project folder.
2. Make a copy and rename it to `.env`.
3. Open `.env` and fill in your Azure credentials and settings.  
   > **Tip:** You can find these values in your Azure Portal under each service's "Keys" or "Connection Strings" section.

### 4. Install Dependencies

First, install `uv` by following the instructions on the [official uv installation page](https://github.com/astral-sh/uv#installation).

Then, install the project dependencies:

```sh
uv sync
```

### 5. Start the Application

To launch the app, run:

```sh
uv run uvicorn "src.application:app" --reload
```

You can also use **F5** in your IDE (such as VS Code) for a live debug session.

The application should now be running. Follow any instructions in the terminal.

## Troubleshooting

- **Missing environment variables:** Double-check your `.env` file for typos or missing values.
- **Azure errors:** Make sure your Azure resources are active and your credentials are correct.
- **Need help?** Search for error messages online or check the Azure documentation.

## Azure Best Practices

- Never share your `.env` file or secrets publicly.
- Use [Azure Key Vault](https://learn.microsoft.com/azure/key-vault/general/basic-concepts) for secure secret management.
- Assign only necessary permissions to your Azure resources.
- Monitor your Azure usage to avoid unexpected costs.

## Learn More

- [Azure OpenAI Documentation](https://learn.microsoft.com/azure/cognitive-services/openai/)
- [Azure Cosmos DB Documentation](https://learn.microsoft.com/azure/cosmos-db/)
- [Azure Blob Storage Documentation](https://learn.microsoft.com/azure/storage/blobs/)

## License

MIT License

