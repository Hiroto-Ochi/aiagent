# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from abc import ABCMeta, abstractmethod
from dataclasses import dataclass

import aiofiles
from azure.core.exceptions import AzureError
from azure.storage.blob.aio import ContainerClient
from fastapi import UploadFile


class BlobRepository(metaclass=ABCMeta):
    """
    Abstract base class for a Blob Repository.
    This class defines the interface for interacting with a blob storage system.
    It includes an abstract method for uploading a file to the blob storage.
    Methods:
        upload_blob(file: UploadFile):
            Abstract method to upload a file to the blob storage. Must be implemented by subclasses.
    """
      
    @abstractmethod
    async def upload_blob(self, file: UploadFile):
        pass

@dataclass(frozen=True)
class LocalBlobRepository(BlobRepository):
    """
    A repository class for handling blob storage operations locally.
    Attributes:
        blob_dict (dict): A dictionary to store blob metadata or references.
    Methods:
        upload_blob(file: UploadFile):
            Asynchronously uploads a file to the local file system.
    """
    blob_dict = {}

    async def upload_blob(self, file: UploadFile):
        """
        Asynchronously uploads a file to a specified location on the server.
        Args:
            file (UploadFile): The file to be uploaded, provided as an instance of UploadFile.
        Writes:
            The content of the uploaded file to a local directory (`./files/`) with the same filename.
        Raises:
            Any exceptions raised during file reading or writing will propagate to the caller.
        """    
        file_location = f"./files/{file.filename}"
        async with aiofiles.open(file_location, 'wb+') as out_file:
            content = await file.read()  # async read
            await out_file.write(content)  # async write

@dataclass(frozen=True)
class AzureBlobRepository(BlobRepository):
    """
    AzureBlobRepository is a repository class for handling operations with Azure Blob Storage.
    Methods:
        upload_blob(file: UploadFile):
            Asynchronously uploads a file to the Azure Blob Storage container.
    """
    

    container_client: ContainerClient

    async def upload_blob(self, file: UploadFile):
        """
        Asynchronously uploads a file to Azure Blob Storage.
        Args:
            file (UploadFile): The file to be uploaded. It should be an instance of `UploadFile` 
                               containing the file's content and metadata.
        Returns:
            None: If the upload fails due to an AzureError.
            Otherwise, the method completes successfully without returning a value.
        Raises:
            AzureError: If there is an issue with the Azure Blob Storage operation.
        Note:
            This method reads the entire file content into memory before uploading. 
            Ensure that the file size is manageable to avoid memory issues.
        """

        try:
            blob_client = self.container_client.get_blob_client(file.filename)
            f = await file.read()
            await blob_client.upload_blob(f)
        except AzureError:
            print(f"Error saving blob file {file.filename} to blob")
            return None
