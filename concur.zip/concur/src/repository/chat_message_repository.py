# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from abc import ABCMeta, abstractmethod
from dataclasses import dataclass

from azure.core.exceptions import AzureError
from azure.cosmos import ContainerProxy
from semantic_kernel.contents.chat_history import ChatHistory, ChatMessageContent


class ChatMessageRepository(metaclass=ABCMeta):
    """
    Abstract interface for managing chat messages in a session.
    This service provides methods to retrieve and store chat messages
    associated with a specific session.
    Methods:
        get_chat_messages(session_id: str) -> ChatHistory:
            Retrieve the chat history for a given session ID.
        set_chat_messages(session_id: str, chat_messages: ChatHistory):
            Store the chat messages for a given session ID.
    """
    
    @abstractmethod
    def get_chat_messages(self, session_id: str) -> ChatHistory:
        pass

    @abstractmethod
    def set_chat_messages(self, session_id: str, chat_messages: ChatHistory):
        pass

@dataclass(frozen=True)
class LocalChatMessageRepository(ChatMessageRepository):
    """
    A local implementation of the ChatMessageRepository that stores chat messages
    in memory using a dictionary.
    Attributes:
        chat_messages_dict (dict): A dictionary to store chat messages, where
            the key is the session ID (str) and the value is the chat history (ChatHistory).
    """
    
    chat_messages_dict = {}

    def get_chat_messages(self, session_id: str) -> ChatHistory:
        """
        Retrieve chat messages associated with a specific session ID.
        Args:
            session_id (str): The unique identifier for the chat session.
        Returns:
            ChatHistory: The chat messages associated with the given session ID,
                         or None if no messages are found for the session.
        """

        return self.chat_messages_dict.get(session_id, None)

    def set_chat_messages(self, session_id: str, chat_messages: ChatHistory):
        """
        Stores chat messages for a given session ID.
        Args:
            session_id (str): The unique identifier for the chat session.
            chat_messages (ChatHistory): The chat history object containing messages to be stored.
        Returns:
            None
        """

        self.chat_messages_dict[session_id] = chat_messages

@dataclass(frozen=True)
class CosmosChatMessageRepository(ChatMessageRepository):
    """
    CosmosDB implementation of the ChatMessageRepository interface.
    This service provides methods to interact with chat messages stored in a CosmosDB database.
    It allows retrieving and storing chat messages for a specific session.
    Attributes:
        client (CosmosClient): The CosmosDB client used to interact with the database.
        database_name (str): The name of the CosmosDB database.
        container_name (str): The name of the CosmosDB container.
    Methods:
        __post_init__():
            Initializes the CosmosDB client, database, and container.
        get_chat_messages(session_id: str) -> ChatHistory:
            Retrieves chat messages for a given session ID.
        set_chat_messages(session_id: str, chat_messages: ChatHistory):
            Stores chat messages for a given session ID.

    https://github.com/microsoft/semantic-kernel/blob/main/python/samples/concepts/chat_history/store_chat_history_in_cosmosdb.py
    """

    cosmos_container: ContainerProxy
    
    def get_chat_messages(self, session_id: str) -> ChatHistory:
        try:
            record = self.cosmos_container.read_item(item=session_id, partition_key=session_id)
            if record:
                messages = ChatHistory()
                for message in record['chat_messages']:
                    messages.add_message(ChatMessageContent.model_validate(message))
                return messages
        except AzureError as e:
            print(f"Error retrieving chat messages: {e}")
            return None

    def set_chat_messages(self, session_id: str, chat_messages: ChatHistory):
        try:
            self.cosmos_container.upsert_item(
                body={
                    'id': session_id,
                    'session_id': session_id,
                    'chat_messages': [msg.model_dump() for msg in chat_messages.messages],
                }
            )
        except AzureError as e:
            print(f"Error setting chat messages: {e}")

