# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""plugins that conatins the plugin for the expense report.

This module defines Plugin classes which will be loaded into the Kernel (semantic-kernel).
"""

import asyncio
import json
from typing import Annotated

from semantic_kernel.functions.kernel_function_decorator import kernel_function

""" ExpensePlugin class

This class is a mock plugin to simulate handling expense related requests.
"""
class ExpensePlugin:
    @kernel_function(name="create_expense_report", description="Create an expense report") 
    async def create_expense_report(
        self, 
        phone_number: Annotated[str, "The phone number of the employee"],
        report_date: Annotated[str, "The date of the report. Ask the date to fill the value"],
        policy: Annotated[str, "The Policy of the report"] = "RCL 立替・国内出張",
        report_name: Annotated[str, """
                               The name of the report. Replace the yyyy and mm by using the report_date. 
                               If the date is 2024-01-01, then the report name should be 立替_2024_01月分
                               """] = "立替_yyyy_mm月分",
    ) -> Annotated[str, "message"]:
        # Simulate a long-running operation
        await asyncio.sleep(1)
        report_header = {
            "phone_number": phone_number,
            "report_date": report_date,
            "policy": policy,
            "report_name": report_name,
        }
        print(json.dumps(report_header, indent=2, ensure_ascii=False))
        return "report created"

    @kernel_function(name="create_report_item", description="Create an expense report item.") 
    async def create_report_item(
        self, 
        file_path: Annotated[str, "The attachment file path of Azure Blob Storage."]
    ) -> Annotated[str, "message"]:
        # Simulate a long-running operation
        await asyncio.sleep(1)
        report_item = {
                "file_path": file_path,
        }
        print(json.dumps(report_item, indent=2, ensure_ascii=False))
        return "report item created"
    
    @kernel_function(name="add_item_to_report", description="Add an created item to the report") 
    async def add_item_to_report(
        self, 
        type: Annotated[str, """The report item type. The choises are: 
                        01.社内会議の室料（飲食会場除く), 
                        02.社内会議の飲食（打ち上げ飲食除く), 
                        03.社内会議のための業務宿泊費, 
                        04.個別面談・フォロー,05.グループ打上・懇親会"""],
        purpose: Annotated[str, "The purpose of the report. The choises are: それ以外(10%), 軽減税率の食品(8%)"],
        payee: Annotated[str, "The name of the payee"],
        report_item_status: Annotated[str, "The status of the report item. The choises are: 紙領収書, 電子領収書"],
        location: Annotated[str, """
                            The location where an employee payed the fee. Confirm if the default value is correct.
                            """] = "Tokyo",
    ) -> Annotated[str, "The submitted report header"]:
        # Simulate a long-running operation
        await asyncio.sleep(1)
        report = {
            "type": type,
            "purpose": purpose,
            "payee": payee,
            "report_item_status": report_item_status,
            "location": location,
        }
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return "item added to the report"
    
    @kernel_function(name="submit_report", description="Submit the report to the system") 
    async def submit_report(
        self, 
    ) -> Annotated[str, "message"]:
        # Simulate a long-running operation
        await asyncio.sleep(1)
        return "item report has been submitted."