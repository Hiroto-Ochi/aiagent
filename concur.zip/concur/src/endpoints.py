# # Copyright (c) Microsoft Corporation.
# # Licensed under the MIT License.

from typing import Annotated

from dependency_injector.wiring import Provide, inject
from fastapi import APIRouter, Depends, UploadFile

from semantic_kernel.connectors.ai.open_ai import AzureChatPromptExecutionSettings
from semantic_kernel.contents.chat_history import ChatHistory
from semantic_kernel.functions.kernel_arguments import KernelArguments
from semantic_kernel.kernel import Kernel

from .containers import Container
from .models import ChatRequest, ChatResponse
from .repository import BlobRepository, ChatMessageRepository


_SYSTEM_MESSAGE = """
    # Role
    You are an expense agent who helps employees to create and submit expoense reports on behalf of employees. 
    You can help them to create and submit expense reports by using function callings.

    # Rule
    There are steps to create the expense report:
    1. Create an expense report.
    2. Create a report item for a report.
    3. Once an employee finish creatin report item, then add it to the expense report.
    4. If an emplyee wants to add a new item to the report, then repeat step 2 and 3.
    5. Once all the items are added to the report, then confirm if the report is correct and submit it.

    Reply in user's language.

    """
async def chat_function(
        chat_request: ChatRequest,
        kernel: Kernel, 
        request_settings: AzureChatPromptExecutionSettings,
        chat_message_service: ChatMessageRepository,
    ) -> str:
        """
        Handles the chat functionality by processing user input, maintaining chat history, 
        and invoking the kernel to generate a response.
        Args:
            chat_request (ChatRequest): The request object containing user input and session ID.
            kernel (Kernel): The kernel instance used to add and invoke chat functions.
            request_settings (AzureChatPromptExecutionSettings): Settings for executing the chat prompt.
            chat_message_service (ChatMessageRepository): Service for retrieving and storing chat messages.
        Returns:
            str: The generated response from the chat function.
        Raises:
            Exception: If there are issues with invoking the kernel or processing chat messages.
        """
        chat_messages = chat_message_service.get_chat_messages(chat_request.session_id)
        chat_history = ChatHistory(
            system_message=_SYSTEM_MESSAGE
        )
        if chat_messages is not None:
            for message in chat_messages:
                chat_history.add_message(message)

        chat_function = kernel.add_function(
            plugin_name="ChatBot",
            function_name="Chat",
            prompt="{{$chat_history}}{{$user_input}}",
            template_format="semantic-kernel",
        )

        answer = await kernel.invoke(
            chat_function, KernelArguments(
                settings=request_settings, 
                user_input=chat_request.user_input, 
                chat_history=chat_history)
        )
        chat_messages = answer.metadata["messages"]
        chat_messages.add_assistant_message(str(answer))
        chat_messages.messages.remove(chat_messages.messages[0])
        chat_message_service.set_chat_messages(chat_request.session_id, chat_messages)
        return str(answer)

router = APIRouter()

@router.post("/chat", response_model=ChatResponse)
@inject
async def chat(
        chat_request: ChatRequest,
        kernel: Annotated[Kernel, Depends(Provide[Container.kernel])],
        request_settings: Annotated[AzureChatPromptExecutionSettings, Depends(Provide[Container.request_settings])],
        chat_message_service: Annotated[ChatMessageRepository, Depends(Provide[Container.chat_message_repository])],
    ) -> ChatResponse:
    """
    Handles chat requests and generates a response.
    This asynchronous endpoint processes a chat request by utilizing the provided
    kernel, request settings, and chat message service. It invokes the `chat_function`
    to generate an answer and returns it wrapped in a `ChatResponse` object.
    Args:
        chat_request (ChatRequest): The incoming chat request containing user input.
        kernel (Kernel): The kernel instance used for processing the chat request.
        request_settings (AzureChatPromptExecutionSettings): Configuration settings
            for executing the chat prompt.
        chat_message_service (ChatMessageRepository): Service for managing chat
            message persistence and retrieval.
    Returns:
        ChatResponse: The response containing the generated answer as a string.
    """
    answer = await chat_function(
        chat_request=chat_request,
        kernel=kernel, 
        request_settings=request_settings,
        chat_message_service=chat_message_service,
    )
    return ChatResponse(answer=str(answer))

@router.post("/uploadfile/{session_id}", response_model=ChatResponse)
@inject
async def upload_file(
        session_id: str,
        file: UploadFile,
        kernel: Annotated[Kernel, Depends(Provide[Container.kernel])],
        request_settings: Annotated[AzureChatPromptExecutionSettings, Depends(Provide[Container.request_settings])],
        chat_message_service: Annotated[ChatMessageRepository, Depends(Provide[Container.chat_message_repository])],
        blob_service: Annotated[BlobRepository,Depends(Provide[Container.blob_repository])]
    ) -> ChatResponse:
    
    """
    Handles the upload of a file and processes it using a chat function.
    Args:
        session_id (str): The unique identifier for the session.
        file (UploadFile): The file to be uploaded.
        kernel (Kernel): The kernel instance provided by dependency injection.
        request_settings (AzureChatPromptExecutionSettings): The settings for the Azure chat prompt execution.
        chat_message_service (ChatMessageRepository): The service for managing chat messages.
        blob_service (BlobRepository): The service for managing blob storage.
    Returns:
        ChatResponse: The response from the chat function after processing the uploaded file.
    """

    await blob_service.upload_blob(file)
    chat_request = ChatRequest(
        session_id=session_id,
        user_input=file.filename
    )
    answer = await chat_function(
        chat_request=chat_request,
        kernel=kernel, 
        request_settings=request_settings,
        chat_message_service=chat_message_service,
    )
    return ChatResponse(answer=str(answer))