# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

import os

from dotenv import load_dotenv

load_dotenv() 

print("→ UseAzure:", os.getenv("UseAzure"))
print("→ COSMOS_DB_URL:", os.getenv("COSMOS_DB_URL"))

from dependency_injector import providers 
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from . import endpoints 
from .containers import Container 
from .repository import (
    AzureBlobRepository, 
    CosmosChatMessageRepository, 
    LocalBlobRepository,
    LocalChatMessageRepository,
)

def create_app() -> FastAPI:
    container = Container()
    # Override the default repositories depending on the environment variable
    if os.getenv("UseAzure") is None or os.getenv("UseAzure") == "False":
        container.chat_message_repository.override(providers.Singleton(LocalChatMessageRepository))
        container.blob_repository.override(providers.Singleton(LocalBlobRepository))
    else:
        container.chat_message_repository.override(providers.Singleton(
            CosmosChatMessageRepository,
            cosmos_container=container.cosmos_container()
        ))

        container.blob_repository.override(providers.Singleton(
            AzureBlobRepository,
            container_client=container.blob_container_client()
        ))
    app = FastAPI() 
    app.container = container
    app.include_router(endpoints.router)
    app.mount("/", StaticFiles(directory="static", html=True), name="static")

    return app

app = create_app()