# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from pydantic import BaseModel


class ChatRequest(BaseModel):
    """
    Request model for chat messages.
    Attributes:
        user_input (str): The input message from the user.
        session_id (str): The unique identifier for the chat session.
    """
    
    user_input: str
    session_id: str


class ChatResponse(BaseModel):
    """
    ChatResponse represents the response structure for a chat interaction.

    Attributes:
        answer (str): The response text provided by the chat system.
    """
    answer: str