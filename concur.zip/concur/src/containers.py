# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

import os

from azure.cosmos import ContainerProxy, CosmosClient, PartitionKey
from azure.storage.blob.aio import BlobServiceClient, ContainerClient
from dependency_injector import containers, providers
from semantic_kernel.connectors.ai.function_choice_behavior import FunctionChoiceBehavior
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion, AzureChatPromptExecutionSettings
from semantic_kernel.kernel import Kernel

from .plugins import ExpensePlugin
from .repository import BlobRepository, ChatMessageRepository

_SERVICE_ID = "default"
class Container(containers.DeclarativeContainer):
    """
    https://python-dependency-injector.ets-labs.org/
    Container class for dependency injection and configuration.
    This class defines and configures various providers and dependencies 
    used in the application, including settings, services, plugins, and 
    repositories. It also conditionally initializes Azure-specific resources 
    such as Cosmos DB and Blob Storage based on environment variables.
    """

    wiring_config = containers.WiringConfiguration(modules=[".endpoints"])

    request_settings = AzureChatPromptExecutionSettings(service_id=_SERVICE_ID)
    request_settings.function_choice_behavior = FunctionChoiceBehavior.Auto(filteres={"excluded_plugins":["ChatBot"]})
    request_settings = providers.Object(
        request_settings
    )

    kernel = Kernel()
    kernel.add_service(
        AzureChatCompletion(
            service_id=_SERVICE_ID,
        ),
    )

    kernel.add_plugin(ExpensePlugin(), "ExpensePlugin")
    kernel = providers.Object(
        kernel        
    )

    # Abstract Repositories
    chat_message_repository = providers.AbstractSingleton(ChatMessageRepository)
    blob_repository = providers.AbstractSingleton(BlobRepository)

    if os.getenv("UseAzure") == "True":
        cosmos_container: ContainerProxy = CosmosClient(
            url=os.getenv("COSMOS_DB_URL"),
            credential=os.getenv("COSMOS_DB_KEY")
        ).create_database_if_not_exists(id=os.getenv("COSMOS_DB_NAME")
        ).create_container_if_not_exists(
                id=os.getenv("COSMOS_DB_CONTAINER_NAME"),
                partition_key=PartitionKey(path="/session_id"),
                offer_throughput=400)

        cosmos_container = providers.Object(
            cosmos_container
        )

        blob_container_client: ContainerClient = BlobServiceClient(
            os.getenv("BLOB_URL"), credential=os.getenv("BLOB_KEY")
            ).get_container_client(os.getenv("BLOB_CONTAINER_NAME"))
        
        blob_container_client = providers.Object(
            blob_container_client
        )
