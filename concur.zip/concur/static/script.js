// セッション ID を localStorage で保持
let sessionId = localStorage.getItem("sessionId");
if (!sessionId) {
  sessionId = crypto.randomUUID();
  localStorage.setItem("sessionId", sessionId);
}

const msgs = document.getElementById('messages');
const form = document.getElementById('input-form');
const input = document.getElementById('user-input');
const fileInput = document.getElementById('file-input');
const attachBtn = document.getElementById('attach-btn');

attachBtn.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', () => {
  if (fileInput.files.length) {
    sendFile(fileInput.files[0]);
    fileInput.value = '';
  }
});

// バブル追加
function appendBubble(text, who) {
  const div = document.createElement('div');
  div.className = `message ${who}`;
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  bubble.textContent = text;
  if (who === 'bot') {
    const img = document.createElement('img');
    img.src = 'bot.png'; img.className = 'avatar';
    div.appendChild(img);
  }
  if (who === 'user') {
    const img = document.createElement('img');
    img.src = 'user.png'; img.className = 'avatar';
    div.appendChild(img);
  }
  div.appendChild(bubble);
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

// テキスト送信
async function sendText(text) {
  appendBubble(text, 'user');
  const res = await fetch('/chat', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ session_id: sessionId, user_input: text })
  });
  if (!res.ok) return appendBubble(`エラー: ${res.status}`, 'bot');
  const { answer } = await res.json();
  appendBubble(answer, 'bot');
}

// ファイル送信
async function sendFile(file) {
  appendBubble(`📎 ${file.name} を送信中…`, 'user');
  const fd = new FormData(); fd.append('file', file);
  const res = await fetch(`/uploadfile/${sessionId}`, { method: 'POST', body: fd });
  if (!res.ok) return appendBubble(`ファイル送信エラー: ${res.status}`, 'bot');
  const { answer } = await res.json();
  appendBubble(answer, 'bot');
}

// フォーム submit ハンドラ
form.addEventListener('submit', e => {
  e.preventDefault();
  const text = input.value.trim();
  if (text) sendText(text);
  input.value = '';
});

// 初回挨拶
window.addEventListener('load', () => {
  appendBubble('こんにちは！経費精算のお手伝いをします。ご質問は何でもどうぞ。', 'bot');
});